module.exports = {
    app_key: '8BCC051034B77818A7732EBF575F1DC2',
    app_secret: 'tgqc4x53kxCm88SoMCsDYxJWngET4HTOLZO9QW9fpTuvrCvVIJQB0ckTyr'
}